package com.klef.jfsd.exam;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = factory.openSession();
        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();

            // Insert records
            Project project1 = new Project();
            project1.setProjectName("AI Research");
            project1.setDuration(12);
            project1.setBudget(50000);
            project1.setTeamLead("John Doe");

            Project project2 = new Project();
            project2.setProjectName("Web Development");
            project2.setDuration(6);
            project2.setBudget(25000);
            project2.setTeamLead("Jane Smith");

            session.save(project1);
            session.save(project2);

            transaction.commit();

            // Criteria Query: Aggregate Functions
            Criteria criteria = session.createCriteria(Project.class);

            // Count
            criteria.setProjection(Projections.rowCount());
            System.out.println("Total Projects: " + criteria.uniqueResult());

            // Sum of Budgets
            criteria.setProjection(Projections.sum("budget"));
            System.out.println("Total Budget: " + criteria.uniqueResult());

            // Average Budget
            criteria.setProjection(Projections.avg("budget"));
            System.out.println("Average Budget: " + criteria.uniqueResult());

            // Max Budget
            criteria.setProjection(Projections.max("budget"));
            System.out.println("Max Budget: " + criteria.uniqueResult());

            // Min Budget
            criteria.setProjection(Projections.min("budget"));
            System.out.println("Min Budget: " + criteria.uniqueResult());
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
            factory.close();
        }
    }
}
